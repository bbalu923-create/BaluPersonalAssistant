package com.balu.personalassistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object ReminderScheduler {
    // Sunday=1 ... Saturday=7 in Calendar
    private data class Shift(val day: Int, val hour: Int, val minute: Int, val label: String, val id: Int)
    private val shifts = listOf(
        Shift(Calendar.MONDAY, 9, 0, "General Shift starts at 9:00 AM", 1),
        Shift(Calendar.TUESDAY, 14, 0, "Second Shift starts at 2:00 PM", 2),
        Shift(Calendar.WEDNESDAY, 6, 0, "First Shift starts at 6:00 AM", 3),
        Shift(Calendar.THURSDAY, 6, 0, "First Shift starts at 6:00 AM (Double Shift)", 4),
        Shift(Calendar.THURSDAY, 22, 0, "Night Shift starts at 10:00 PM (Double Shift)", 5),
        Shift(Calendar.FRIDAY, 22, 0, "Night Shift starts at 10:00 PM", 6)
    )

    fun scheduleAll(context: Context, leadMinutes: Int) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        shifts.forEach { shift ->
            val intent = Intent(context, ReminderReceiver::class.java).putExtra("message", shift.label)
            val pi = PendingIntent.getBroadcast(context, shift.id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val next = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_WEEK, shift.day)
                set(Calendar.HOUR_OF_DAY, shift.hour)
                set(Calendar.MINUTE, shift.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.MINUTE, -leadMinutes)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 7)
            }
            alarm.setRepeating(AlarmManager.RTC_WAKEUP, next.timeInMillis, 7L * 24 * 60 * 60 * 1000, pi)
        }

        // Daily 7:00 PM attendance reminder on all seven days, including ARR and R.
        val dailyIntent = Intent(context, ReminderReceiver::class.java)
            .putExtra("message", "தினசரி நினைவூட்டல்: மாலை 7 மணிக்கு Shift Attendance பதிவு செய்யுங்கள்")
        val dailyPi = PendingIntent.getBroadcast(context, 700, dailyIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val dailyNext = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 19)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 1)
        }
        alarm.setRepeating(AlarmManager.RTC_WAKEUP, dailyNext.timeInMillis, AlarmManager.INTERVAL_DAY, dailyPi)
    }

    fun cancelAll(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        shifts.forEach { shift ->
            val pi = PendingIntent.getBroadcast(context, shift.id,
                Intent(context, ReminderReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarm.cancel(pi)
        }
        val dailyPi = PendingIntent.getBroadcast(context, 700,
            Intent(context, ReminderReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarm.cancel(dailyPi)
    }
}
