package com.balu.personalassistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences("balu", Context.MODE_PRIVATE)
            if (prefs.getBoolean("enabled", false)) {
                ReminderScheduler.scheduleAll(context, prefs.getInt("lead", 30))
            }
        }
    }
}
