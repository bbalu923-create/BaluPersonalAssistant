package com.balu.personalassistant

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("balu", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return
        val message = intent.getStringExtra("message") ?: "உங்கள் Shift Reminder"
        val notification = Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Balu Personal Assistant")
            .setContentText(message)
            .setAutoCancel(true)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(message.hashCode(), notification)
    }

    companion object {
        const val CHANNEL_ID = "balu_shift_reminders"
        fun createChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val channel = NotificationChannel(CHANNEL_ID, "Shift reminders", NotificationManager.IMPORTANCE_HIGH)
                (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
            }
        }
    }
}
